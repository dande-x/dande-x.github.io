About MTPT
--------------------
MTPT is based on the NexusPHP project, with many improvements.
You can get it from http://github.com/MTPT/mtpt/

LICENSE
--------------------
This project is based on GPL release agreement, you will get an LICENSE file with mtpt, you can get the source code for free, to modify the source code you must follow the GPL agreement.

INSTALLATION
--------------------
To install mtpt on your local machine please see INSTALL.txt in this folder.

CONTACT
--------------------
You can contact us at http://www.xnlinux.cn/  or mail us:

- JinyaChen#gmail.com
- qutengjiao#gmail.com
- mtpt#nwsuaf.edu.cn
* (replace # with @)

Update in 0.3
--------------------------
增加偷麦粒应用，彩票应用，改名，购买促销应用
群聊自动喊话机器人
求种，回收站，自助求邀，标题自动生成系统
自动获取imdb和豆瓣链接系统
完善考核系统
添加二级分类图标
自助绑定学号
完善站内信，加入@功能，引用发布功能
更容易安装使用

Install tips
-------------
需要memcache支持
需要打开php短标签标记: short_open_tag = On
导入数据库，配置代码，修改config/allconfig.php内baseurl、数据库、邮箱等关键配置
需要给invite文件夹、shoutbox_new.html等需要进行读写操作的文件、文件夹写入权限

TODO
-----
主要的缺点是多语言支持被破坏了，以及配置起来更麻烦
更改的配置相关的代码直接写到了相应页面
输出也直接用简体中文方式写到了相应页面
这使得代码的整改挪用变得十分困难，需要查看、修改每个页面才能至少把麦粒，麦田等相关词语改掉


Contributors
------------
扬扬，xhf，cide，samurai7，EINino，zhaojiajia，沉浮江湖，F12
北洋园-喵喵，蚂蚁-真红酱


