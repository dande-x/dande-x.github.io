<?php

$lang_users = array
(
	'head_users' => "用戶",
	'text_users' => "<h1>用戶</h1>\n",
	'text_search' => "搜索:",
	'select_any_class' => "(任何等級)",
	'submit_okay' => "給我搜",
	'text_prev' => "上一頁",
	'text_next' => "下一頁",
	'col_user_name' => "用戶名",
	'col_registered' => "註冊",
	'col_last_access' => "最後訪問",
	'col_class' => "等級",
	'col_country' => "國家/地區",
	'select_any_country'=> "(任何國家/地區)",
);

?>
