<?php

$lang_checkuser = array
(
	'std_error' => "錯誤",
	'std_no_user_id' => "沒有該ID的用戶！",
	'std_no_permission' => "你沒有該權限",
	'head_detail_for' => "用戶詳情 - ",
	'text_account_disabled' => "<p><b>該帳號被禁用！</b></p>\n",
	'row_join_date' => "加入日期",
	'row_gender' => "性別",
	'row_email' => "郵箱",
	'row_ip' => "IP",
	'submit_confirm_this_user' => "確認該用戶"
);

?>
