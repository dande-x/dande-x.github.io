<?php

$lang_iphistory = array
(
	'std_error' => "錯誤",
	'std_invalid_id' => "無效的ID",
	'text_user_not_found' => "沒有該用戶",
	'head_ip_history_log_for' => "用戶IP曆史 - ",
	'text_historical_ip_by' => "用戶IP位址曆史 - ",
	'col_last_access' => "最近存取",
	'col_ip' => "IP",
	'col_hostname' => "主機名",
	'text_not_available' => "無",
	'text_duplicate' => "重複",
);
?>
