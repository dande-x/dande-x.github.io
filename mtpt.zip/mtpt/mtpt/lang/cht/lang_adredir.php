<?php

$lang_adredir = array
(
	'std_error' => "錯誤",
	'std_ad_system_disabled' => "廣告系統關閉中。",
	'std_invalid_ad_id' => "無效的廣告ID",
	'std_no_redirect_url' => "無跳轉鏈結。"
);

?>
