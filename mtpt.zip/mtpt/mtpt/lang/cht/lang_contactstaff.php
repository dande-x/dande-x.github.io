<?php

$lang_contactstaff = array
(
	'head_contact_staff' => "聯繫管理組",
	'text_message_to_staff' => "給管理組發短訊",
	'row_subject' => "標題",
	'row_body' => "正文",
	'submit_send_it' => "發送"
);

?>
