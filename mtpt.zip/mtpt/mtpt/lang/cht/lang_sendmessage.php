<?php

$lang_sendmessage = array
(
	'std_error' => "錯誤",
	'std_permission_denied' => "沒有該許可權",
	'head_send_message' => "發送短訊",
	'text_mass_message' => "群發短訊給",
	'text_users' => "個用戶",
	'text_subject' => "主題：",
	'text_comment' => "評論：",
	'text_from' => "發送者：",
	'text_take_snapshot' => "使用快照：",
	'submit_send_it' => "發送",
	'submit_preview' => "預覽",
	'text_templates' => "模版：",
	'submit_use' => "使用",
	'std_no_user_id' => "沒有該ID的用戶。",
	'text_message_to' => "發送短訊給",
	'checkbox_delete_message_replying_to' => "回復後刪除",
	'checkbox_save_message_to_sendbox' => "保存到發件箱"
);

?>