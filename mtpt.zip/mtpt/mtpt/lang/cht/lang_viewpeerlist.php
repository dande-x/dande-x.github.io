<?php

$lang_viewpeerlist = array
(
	'col_user_ip' => "用戶",
	'col_location' => "地點",
	'col_connectable' => "可連接",
	'col_uploaded' => "上傳",
	'col_rate' => "即時速度",
	'col_av_rate' => "平均速度",
	'col_downloaded' => "下載",
	'col_ratio' => "分享率",
	'col_complete' => "完成",
	'col_connected' => "連接時間",
	'col_idle' => "最近匯報",
	'col_client' => "用戶端",
	'text_anonymous' => "匿名",
	'text_unknown' => "(未知)",
	'text_seeders' => "做種者",
	'text_leechers' => "下載者",
	'row_seeders' => "做種者",
	'row_leechers' => "下載者",
	'text_yes' => "是",
	'text_no' => "否",
	'text_inf' => "無限"
);

?>
