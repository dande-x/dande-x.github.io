<?php

$lang_takecontact = array
(
	'std_error' => "錯誤",
	'std_method' => "方式",
	'std_please_enter_something' => "請填寫內容！",
	'std_please_define_subject' => "你必須輸入標題！",
	'std_message_flooding' => "不允許濫發短訊，請在",
	'std_second' => "秒",
	'std_s' => "",
	'std_before_sending_pm' => "後重試。",
	'std_succeeded' => "成功",
	'std_message_succesfully_sent' => "短訊成功發送！"
);

?>