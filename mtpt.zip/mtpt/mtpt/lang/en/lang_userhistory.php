<?php

$lang_userhistory = array
(
	'std_error' => "Error",
	'std_permission_denied' => "Permission denied",
	'std_no_posts_found' => "No posts found",
	'head_posts_history' => "Posts history",
	'text_posts_history_for' => "Post history for ",
	'text_forum' => "<b>Forum:&nbsp;</b>",
	'text_topic' => "<b>Topic:&nbsp;</b>",
	'text_post' => "<b>Post:&nbsp;</b>",
	'text_new' => "NEW!",
	'text_last_edited' => "Last edited by ",
	'text_at' => " at ",
	'std_no_comments_found' => "No comments found",
	'head_comments_history' => "Comments history",
	'text_comments_history_for' => "Comments history for ",
	'text_torrent' => "<b>Torrent:&nbsp;</b>",
	'text_comment' => "<b>Comment:&nbsp;",
	'std_history_error' => "History Error",
	'std_unkown_action' => "Unknown action",
	'std_invalid_or_no_query' => "Invalid or no query."
);

?>
