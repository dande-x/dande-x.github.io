<?php

$lang_deletedisabled = array
(
	'head_delete_diasabled' => "Delete Disabled",
	'text_delete_diasabled' => "Delete Disabled",
	'submit_delete_all_disabled_users' => "Delete all disabled users",
	'text_delete_disabled_note' => "If you click the following button, all disabled users at your site will be <b>DELETED</b>. <b>NEVER</b> click the button unless you are <b>VERY SURE</b>.",
	'text_users_are_disabled' => " users are deleted."
);

?>
