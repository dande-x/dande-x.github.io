<?php

$lang_staffbox = array
(
	'head_staff_pm' => "Staff's PM",
	'text_staff_pm' => "Staff's PM",
	'std_sorry' => "Sorry",
	'std_no_messages_yet' => "No messages yet!",
	'col_subject' => "Subject",
	'col_sender' => "Sender",
	'col_added' => "Added",
	'col_answered' => "Answered",
	'col_action' => "Act.",
	'text_yes' => "Yes",
	'text_no' => "No",
	'submit_set_answered' => "Set Answered",
	'submit_delete' => "Delete",
	'text_system' => "System",
	'head_view_staff_pm' => "View Staff's PM",
	'col_from' => "From",
	'col_date' => "Date",
	'col_answered_by' => "Answered by",
	'text_reply' => "Reply",
	'text_mark_answered' => "Mark Answered",
	'text_delete' => "Delete",
	'std_error' => "Error",
	'std_no_user_id' => "No user with that ID.",
	'head_answer_to_staff_pm' => "Answer to Staff PM",
	'text_answering_to' => "Answering to ",
	'text_sent_by' => " sent by ",
	'std_body_is_empty' => "Please enter something!",
);

?>
