<?php

$lang_ipsearch = array
(
	'std_error' => "Error",
	'std_invalid_ip' => "Invalid IP.",
	'std_invalid_subnet_mask' => "Invalid subnet mask.",
	'head_search_ip_history' => "Search in IP History",
	'text_search_ip_history' => "Search in IP History",
	'row_ip' => "IP",
	'row_subnet_mask' => "Subnet Mask",
	'submit_search' => "Search",
	'text_no_users_found' => "No users found",
	'text_users_used_the_ip' => " users have used the IP: ",
	'col_username' => "Username",
	'col_last_ip' => "Last IP",
	'col_last_access' => "Last access",
	'col_ip_num' => "IP Nums",
	'col_last_access_on' => "Last access this IP",
	'col_added' => "Added",
	'col_invited_by' => "Invited by",
	'text_not_available' => "N/A",
);
?>
