<?php

$lang_delete = array
(
	'std_delete_failed' => "Delete failed!",
	'std_missing_form_date' => "missing form data",
	'std_not_owner' => "You're not the owner! How did that happen?",
	'std_invalid_reason' => "Invalid reason ",
	'std_describe_violated_rule' => "Please describe the violated rule.",
	'std_enter_reason' => "Please enter the reason for deleting this torrent.",
	'head_torrent_deleted' => "Torrent deleted!",
	'text_go_back' => "Go back to whence you came",
	'text_back_to_index' => "Back to index",
	'text_torrent_deleted' => "Torrent deleted!"
);

?>
