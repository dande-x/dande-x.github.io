<?php

$lang_takeconfirm = array
(
	'std_sorry' => "Sorry...",
	'std_no_buddy_to_confirm' => "No buddy to confirm. :( <br /><br />Please click  ",
	'std_here_to_go_back' => "here</a> to go back.",
	'mail_title' => " Account Confirmed",	
	'mail_here' => "HERE",	
	'mail_content_1' => "Hello,<br /><br />Your account has been confirmed. You can now visit ",
	'mail_content_2' => "<br /><br />and use your login information to login in. We hope you'll read the FAQ's and Rules before you start sharing files.<br /><br />Good luck and have fun on ".$SITENAME."!<br /><br />If you do not know the person who has invited you, please report this email to ".$REPORTMAIL."<br />------<br />Yours,The ".$SITENAME." Team."
);

?>
