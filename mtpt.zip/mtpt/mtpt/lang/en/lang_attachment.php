<?php

$lang_attachment = array
(
	'text_nothing_received' => "Failure! Nothing received!",
	'text_file_number_limit_reached' => "Failure! You cannot upload more files for the moment. Please wait some time.",
	'text_file_size_too_big' => "Failure! The file size is too big.",
	'text_file_extension_not_allowed' => "Failure! The file extension is not allowed.",
	'text_invalid_image_file' => "Failure! Invalid image file.",
	'text_cannot_move_file' => "Failure! Cannot move uploaded file.",
	'submit_upload' => "Upload",
	'text_left' => "Today Left: ",
	'text_of' => " of ",
	'text_size_limit' => "Size: ",
	'text_file_extensions' => "File Extensions: ",
	'text_mouse_over_here' => "mouse here",
	'text_small_thumbnail' => "small thumbnail",
);

?>
