<?php

$lang_faq = array
(
	'head_faq' => "FAQ",
	'text_welcome_to' => "Welcome to ",
	'text_welcome_content_one' => "The goal is to provide the absolutely high quality stuff. Therefore, only specially authorised users have permission to upload torrents. If you have access to 0-day stuff do not hesitate to <a class=\"faqlink\" href=\"contactstaff.php\">contact</a> us!<br /><br />This is a private tracker, and you have to register before you can get full access to the site.",
	'text_welcome_content_two' =>" Before you do anything here at ".$SITENAME.", we suggest you read the <a class=\"faqlink\" href=\"rules.php\">rules</a>! There are only a few rules to abide by, but we do enforce them!<br /><br />Before you go any further you should read the ".$SITENAME." <a class=\"faqlink\" href=\"useragreement.php\">user agreement</a>.",
	'text_contents' => "Contents",
);

?>
