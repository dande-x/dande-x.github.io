<?php

$lang_checkuser = array
(
	'std_error' => "Error",
	'std_no_user_id' => "No user with this ID!",
	'std_no_permission' => "You have no permission",
	'head_detail_for' => "Details for ",
	'text_account_disabled' => "<p><b>This account has been disabled!</b></p>",
	'row_join_date' => "Join&nbsp;date",
	'row_gender' => "Gender",
	'row_email' => "E-Mail",
	'row_ip' => "IP",
	'submit_confirm_this_user' => "Confirm&nbsp;this&nbsp;user"
);

?>
