<?php

$lang_getusertorrentlistajax = array
(
	'col_type' => "Type",
	'col_name' => "Name",
	'title_size' => "Size",
	'title_seeders' => "Seeders",
	'title_leechers' => "Leechers",
	'col_uploaded' => "Ul.",
	'col_downloaded' => "Dl.",
	'col_ratio' => "Ratio",
	'col_anonymous' => "Anonym.",
	'col_time_completed' => "Sna. at",
	'col_se_time' => "Se. Time",
	'col_le_time' => "Le. Time",
	'text_record' => " record",
	'text_no_record' => "No record.",
);
?>
