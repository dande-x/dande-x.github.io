<?php

$lang_sendmessage = array
(
	'std_error' => "Error",
	'std_permission_denied' => "Permission denied",
	'head_send_message' => "Send message",
	'text_mass_message' => "Mass Message to ",
	'text_users' => "users",
	'text_subject' => "Subject:",
	'text_comment' => "Comment:",
	'text_from' => "From:",
	'text_take_snapshot' => "Take snapshot:",
	'submit_send_it' => "Send it!",
	'submit_preview' => "Preview",
	'text_templates' => "Templates:",
	'submit_use' => "Use",
	'std_no_user_id' => "No user with that ID.",
	'text_message_to' => "Message to ",
	'checkbox_delete_message_replying_to' => "Delete message you are replying to",
	'checkbox_save_message_to_sendbox' => "Save message to Sentbox"
);

?>