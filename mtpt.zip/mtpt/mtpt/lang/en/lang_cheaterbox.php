<?php

$lang_cheaterbox = array
(
	'std_oho' => "Oho!",
	'std_no_suspect_detected' => "No suspect detected yet.",
	'head_cheaterbox' => "Cheaterbox",
	'text_cheaterbox' => "Cheaterbox <font class=striking>BETA</font>",
	'col_added' => "Added",
	'col_suspect' => "Suspect",
	'col_hit' => "Hit",
	'col_torrent' => "Torrent",
	'col_ul' => "UL",
	'col_dl' => "DL",
	'col_ann_time' => "Ann. Time",
	'col_seeders' => "Seeders",
	'col_leechers' => "Leechers",
	'col_comment' => "Comment",
	'col_dealt_with' => "Dealt With",
	'col_action' => "Act.",
	'text_torrent_does_not_exist' => "Torrent doesn't exist or is deleted",
	'text_yes' => "Yes",
	'text_no' => "No",
	'submit_set_dealt' => "Set Dealt",
	'submit_delete' => "Delete"
);

?>
