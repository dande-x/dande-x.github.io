<?php

$lang_mailtest = array
(
	'head_mail_test' => "Mail Test",
	'text_mail_test' => "Mail Test",
	'row_enter_email' => "Enter email",
	'text_enter_email_note' => "Enter an email address to send a test mail, e.g. yourname@gmail.com",
	'submit_send_it' => "Send it!",
	'text_smtp_testing_mail' => " SMTP Testing Mail",
	'std_error' => "Error",
	'std_invalid_email_address' => "Invalid email address!",
	'mail_test_mail_content' => "Hi, If you see this message, your SMTP function works great. Have a nice day.",
	'std_success' => "Success",
	'std_success_note' => "No error found. However this does not mean the mail arrived 100%. Please check the mail."
);

?>
