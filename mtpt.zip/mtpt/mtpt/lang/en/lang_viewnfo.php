<?php

$lang_viewnfo = array
(
	'std_puke' => "Puke",
	'head_view_nfo' => "View NFO File",
	'text_nfo_for' => "NFO for",
	'title_dos_vy' => "",
	'text_dos_vy' => "DOS-vy",
	'title_windows_vy' => "Latin-1: Inget socker tack!",
	'text_windows_vy' => "Windows-vy"
);
?>