<?php

$lang_moforums = array
(
	'head_overforum_management' => "论坛分区管理",
	'text_forum_management' => "论坛管理",
	'text_overforum_management' => "论坛分区管理",
	'col_name' => "名字",
	'col_viewed_by' => "最低允许查看等级",
	'col_modify' => "修改",
	'text_edit' => "编辑",
	'text_delete' => "删除",
	'js_sure_to_delete_overforum' => "你确定要删除此论坛分区吗？",
	'text_no_records_found' => "对不起，没有记录！",
	'text_new_overforum' => "新论坛分区",
	'text_overforum_name' => "名字",
	'text_overforum_description' => "描述",
	'text_minimum_view_permission' => "最低允许阅读等级",
	'text_overforum_order' => "论坛分区排序",
	'text_overforum_order_note' => "按数字升序排列，即0显示在最顶端。",
	'submit_make_overforum' => "创建新的分区",
	'text_edit_overforum' => "编辑分区",
	'submit_edit_overforum' => "编辑分区"
);

?>
