<?php

$lang_freeleech = array
(
	'head_freeleech' => "请选择要进行的操作",
	'text_free' => "设置所有种子为<font size=+1 color=#000099>免费</font>：",
	'text_2xup' => "设置所有种子为<font size=+1 color=#009900>2倍速上传</font>：",
	'text_2xup_free' => "设置所有种子为<font size=+1 color=#009999>2倍速上传且免费</font>：",
	'text_halfdown' => "设置所有种子为<font size=+1 color=#990000>半速下载</font>：",
	'text_2xup_halfdown' => "设置所有种子为<font size=+1 color=#999900>2倍速上传且半速下载</font>：",
	'text_normal' => "设置所有种子为正常状态：",
	'text_go' => "GO"
);

?>
