<?php

$lang_amountupload = array
(
	'head_add_upload' => "增加用户上传量",
	'text_amount' => "上传量",
	'text_unit' => "(单位&nbsp;GB)",
	'text_add_done' => "成功增加上传量，通知消息已发往用户。",
	'text_usergroup' => "用户组",
	'text_subject' => "活动主题",
	'text_reason' => "详细说明",
	'text_operator' => "操作者",
	'submit_do' => "确定",
	'text_note' => "注意：请勿使用BB code代码或HTML代码。"
);

?>
