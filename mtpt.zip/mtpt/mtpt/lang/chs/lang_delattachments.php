<?php

$lang_deletedisabled = array
(
	'head_delete_diasabled' => "删除无用附件",
	'text_delete_diasabled' => "删除无用附件",
	'submit_delete_check' => "检测无用附件",
	'text_delete_check_note' => "如果你点击下面的按钮，将检测网站中所有的无用的附件。如果数据量较大，此执行过程将会比较长，请耐心等待，不要重复执行。",
	'submit_delete_all_disabled_users' => "删除所有无用附件",
	'text_delete_disabled_note' => "如果你点击下面的按钮，网站中所有的无用的附件<b>删除</b>。除非<b>十分确定</b>，否则<b>不要</b>点此按钮。",
	'text_files_are_disabled' => "个无用附件",
	'text_users_are_disabled' => "无用附件已被删除。"
);

?>
