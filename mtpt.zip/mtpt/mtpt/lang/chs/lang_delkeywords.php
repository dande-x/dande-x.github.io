<?php

$lang_adduser = array
(
	'head_keywords' => "删除关键词",
	'text_keywords' => "关键词",
	'submit_del_keywords' => "删除",
);

?>
