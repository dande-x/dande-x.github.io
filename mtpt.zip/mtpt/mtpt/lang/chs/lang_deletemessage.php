<?php

$lang_deletemessage = array
(
	'std_bad_message_id' => "错误短讯ID",
	'std_not_suggested' => "如果我是你，我不会这么做...",
	'std_not_in_inbox' => "你的收件箱中没有该短讯。",
	'std_not_in_sentbox' => "你的发件箱中没有该短讯。",
	'std_unknown_pm_type' => "未知短讯类型。",
);

?>