<?php

$lang_iphistory = array
(
	'std_error' => "错误",
	'std_invalid_id' => "无效的ID",
	'text_user_not_found' => "没有该用户",
	'head_ip_history_log_for' => "用户IP历史 - ",
	'text_historical_ip_by' => "用户IP地址历史 - ",
	'col_last_access' => "最近访问",
	'col_ip' => "IP",
	'col_hostname' => "主机名",
	'text_not_available' => "无",
	'text_duplicate' => "重复",
);
?>
