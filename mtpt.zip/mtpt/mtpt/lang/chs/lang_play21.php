<?php

$lang_play = array
(
	'text_head' => "21点",
	'std_play21_system_disabled' => "对不起，该应用正在开发中。"
);

?>
