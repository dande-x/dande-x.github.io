<?php

$lang_testip = array
(
	'head_testip' => "IP地址检测",
	'text_ip' => "请输入IP地址",
	'text_resultip' => "您检查的IP地址：",
	'text_notbanned' => "当前没有被禁止。",
);

?>
