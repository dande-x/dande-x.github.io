<?php

$lang_clearcache = array
(
	'head_clearcache' => "清空缓存",
	'text_cachename' => "缓存名",
	'text_multilang' => "多语种",
	'text_yes' => "是",
	'submit_ok' => "确定",
);

?>
