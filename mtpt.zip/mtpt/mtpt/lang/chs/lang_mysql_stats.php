<?php

$lang_mysql_stats = array
(
	'head_mysql_stats' => "Mysql数据库状态",
	'text_running' => "MySQL数据库已经持续运行了：",
	'text_started' => "。启动时间为：",
	'text_server_traffic' => "流量统计：",
	'text_server_query' => "SQL查询统计：",
	'text_server_status' => "更多状态参数",
	'text_traffic_desc' => "此表格显示了MySQL服务自启动以来的网络流量统计信息",
	'text_query_desca' => "自服务启动以来，",
	'text_query_descb' => "次查询被发往服务器。",
	'text_traffic' => "流量",
	'text_perhour' => "每小时",
	'text_perminute' => "每分",
	'text_persecond' => "每秒",
	'text_connections' => "连接",
	'text_percentage' => "百分比",
	'form_received' => "接收",
	'form_querytype' => "查询类型",
	'form_sent' => "发送",
	'form_total' => "总计",
	'form_failed' => "失败尝试",
	'form_aborted' => "客户端终止",
	'form_variable' => "参数",
	'form_value' => "值",
);

?>
