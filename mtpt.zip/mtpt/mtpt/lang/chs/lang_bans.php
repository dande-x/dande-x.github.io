<?php

$lang_bans = array
(
	'head_current' => "当前被禁止IP",
	'head_addban' => "添加禁止IP",
	'text_nothing' => "当前没有禁止记录",
	'text_addtime' => "添加时间",
	'text_firstip' => "起始IP",
	'text_lastip' => "结束IP",
	'text_by' => "操作者",
	'text_comment' => "禁止原因",
	'text_act' => "操作",
	'text_remove' => "删除",
	'submit_add' => "添加"
);

?>
