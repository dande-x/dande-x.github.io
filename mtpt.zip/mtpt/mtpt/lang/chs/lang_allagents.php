<?php

$lang_allagents = array
(
	'head_allagents' => "当前在线客户端",
	'text_client' => "客户端",
	'text_peerid' => "Peer ID"
);

?>
