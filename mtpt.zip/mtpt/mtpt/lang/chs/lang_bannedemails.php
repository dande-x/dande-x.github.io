<?php

$lang_bannedemails = array
(
	'text_help1' => "请输入禁止邮件列表(使用空格隔开)：",
	'text_help2' => "禁止单个邮箱请输入“email@domain.com”；",
	'text_help3' => "禁止一个邮件域请输入“@domain.com”。",
	'submit_save' => "保存",
);

?>
