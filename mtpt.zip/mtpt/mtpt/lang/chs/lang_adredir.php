<?php

$lang_adredir = array
(
	'std_error' => "错误",
	'std_ad_system_disabled' => "广告系统关闭中。",
	'std_invalid_ad_id' => "无效的广告ID",
	'std_no_redirect_url' => "无跳转链接。"
);

?>
