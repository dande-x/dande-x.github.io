<?php

$lang_staffmess = array
(
	'head_masspm' => "站内消息群发",
	'text_sendto' => "发送至：",
	'text_send_done' => "消息已成功发往用户。",
	'text_usergroup' => "用户组",
	'text_subject' => "主题",
	'text_sender' => "发送者",
	'submit_do' => "确定",
	'text_note' => "注意：请勿使用BB code代码或HTML代码。"
);

?>
