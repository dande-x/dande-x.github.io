<?php

$lang_reset = array
(
	'head_reset' => "用户密码重置",
	'text_username' => "用户名",
	'text_passwd' => "密码",
	'text_minimum' => "密码最短6位",
	'text_repasswd' => "再次输入密码",
	'submit_reset' => "重置",
);

?>
