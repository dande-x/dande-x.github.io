<?php

$lang_stats = array
(
	'head_uploader_stats' => "会员发布状态",
	'head_category_activity' => "种子分类状态",
	'text_username' => "用户名",
	'text_lastupload' => "最近发布",
	'text_torrents' => "种子数",
	'text_torrents_perc' => "种子百分比",
	'text_peers' => "peer数",
	'text_peers_perc' => "peer百分比",
	'text_category' => "分类",
	'text_note' => "提示：点击各栏名称可以自动排序。",
);

?>
