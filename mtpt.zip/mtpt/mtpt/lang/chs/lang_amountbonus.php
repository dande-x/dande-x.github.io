<?php

$lang_amountbonus = array
(
	'head_amount_bonus' => "用户麦粒奖励发放",
	'text_addtouser' => "发放至指定用户",
	'text_addtoany' => "发放至全站用户",
	'text_add_note1' => "发送麦粒数",
	'text_username' => "用户名",
	'text_bonus' => "麦粒",
	'submit_add' => "确定",
	'text_reason' => "原因",
	'msg_title' => "您的麦粒值有新的变化",
	'msg_add' => "管理组向您发放",
	'msg_sub' => "管理组扣除您",
	'msg_reason' => "麦粒，原因如下：\n"
);

?>
