<?php

$lang_adduser = array
(
	'head_adduser' => "添加用户",
	'text_username' => "用户名",
	'text_passwd' => "密码",
	'text_repasswd' => "再次输入密码",
	'text_email' => "邮箱",
	'submit_add_user' => "确定",
);

?>
