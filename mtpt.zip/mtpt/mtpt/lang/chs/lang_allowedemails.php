<?php

$lang_allowedemails = array
(
	'text_help1' => "请输入允许邮件列表(使用空格隔开)：",
	'text_help2' => "允许单个邮箱请输入“email@domain.com”；",
	'text_help3' => "允许一个邮件域请输入“@domain.com”。",
	'submit_save' => "保存",
);

?>
