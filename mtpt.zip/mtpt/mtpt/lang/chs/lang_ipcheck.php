<?php

$lang_ipcheck = array
(
	'head_ipcheck' => "重复IP用户检查",
	'text_username' => "用户名",
	'text_email' => "邮箱",
	'text_registered' => "注册时间",
	'text_lastaccess' => "最后访问",
	'text_uploaded' => "上传量",
	'text_downloaded' => "下载量",
	'text_ratio' => "分享率",
	'text_ip' => "IP地址",
	'text_peer' => "Peer"
);

?>
