<?php

$lang_massmail = array
(
	'head_massmail' => "全站发送电子邮件（email）",
	'text_classe' => "用户等级",
	'text_subject' => "主题",
	'text_body' => "内容",
	'submit_send' => "发送",
);

?>
