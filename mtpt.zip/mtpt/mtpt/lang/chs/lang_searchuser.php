<?php

$lang_searchuser = array
(
	'head_search' => "用户搜索",
	'text_username' => "用户名",
	'text_usergroup' => "用户组",
	'text_noresult' => "用户名不存在",
	'text_notice' => "&nbsp;用户名之间用\";\"间隔可输多个用户名",
	'submit_search' => "搜索",
	'submit_return' => "重新搜索",
);

?>
