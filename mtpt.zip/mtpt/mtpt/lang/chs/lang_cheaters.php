<?php

$lang_cheaters = array
(
	'head_cheaters' => "可疑作弊用户检查",
	'text_important' => "<font size=+1 color=#990000>注  意！</font>",
	'text_note1' => "尽管这里使用了“作弊”一词，但请牢记这仅仅代表一些统计数据，用户给力，数据也会",
	'text_note2' => "很给力！请根据当前的发生情况做出准确判断，相信作弊值的实际意义能够也必将改变，",
	'text_note3' => "所以在你发送一条警告信息之前应该总是考虑下其他因素，某些账号可能会有一个很高的",
	'text_note4' => "作弊值，但他们从不在生活中作弊，仅仅是因为运气差正好碰上客户端更新tracker，这种",
	'text_note5' => "情况的作弊值会很快降低，而真正作弊的账号作弊值会一直保持很高。",
	'text_class' => "用户等级",
	'text_ratio' => "分享率",
	'text_username' => "用户名",
	'text_registered' => "注册时间",
	'text_uploaded' => "上传量",
	'text_downloaded' => "下载量",
	'text_cheat_value' => "作弊值",
	'text_cheat_spread' => "作弊率",
);

?>
