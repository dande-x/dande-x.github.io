<?php
//	作者：cide
//	时间：2011-11-17
$lang_signin = array
(
	'std_error' => "错误！",
	'std_sorry' => "对不起...",
	'std_permission_denied_only' => "你没有该权限。只有 <strong>论坛版主</strong>，",
	'std_permission_denied_onlyadmin' => "你没有该权限。只有",
	'std_or_above_can_view' => "及以上等级的用户才能查看管理组签到卡。<br /><br />目前签到卡不针对普通用户开放。<br /><br /><b></p>" .$SITENAME."管理组</b>",
	'std_or_admin_can_view' => "及以上等级的用户才能查看管理组签到卡<strong>管理页面。</strong><br /><br />您还是 <br /><img src='/pic/smilies/44.gif'/><font size=16 color=purple>哪凉快哪呆着去...</font><b></p>" .$SITENAME."管理组</b>",
	'text_staff' => "管理组",
	'text_firstline_support' => "一线客服",
	'text_movie_critics' => "美工组",
	'text_username' => "用户名",
	'text_online_or_offline' => "是否在线",
	'title_contact' => "快速联系",
	'text_support_for' => "帮助内容",
	'text_responsible_for' => "负责内容",
	'text_duties' => "职责",
	'title_signin' => "签到板",
	'title_signin2' => "麦田PT 管理群签到卡",
	'title_online' => "在线",
	'title_signin_time' => "签到时间",
	'title_leave' => "请假",
	'title_note' => "备注",
	'title_offline' => "不在线",
	'title_send_pm' => "发送短讯",
	'title_history' => "签到历史",
	'title_todaySignin' => "今日签到",
	'title_online' => "当前在线",
	'title_todaySignin' => "今日签到",
	'title_todaySignin' => "今日签到",
	'title_return_signin' => "返回签到卡",
	'text_vip' => "VIP贵宾",
	'text_reason' => "原因",
	'text_forum_moderators' => "论坛版主",
	'text_forums' => "版块",
	'text_permit_leave_one' => "这个孩纸 在 ",
	'text_leave_one' => "请假成功！<br>",
	'text_permit' => "批准成功！",
	'text_error' => "批准出错！ = =！",
	'text_record_exist_1' => "及之后这段时间内，",
	'text_record_exist_2' => " 这孩纸 有打卡记录，太2了 = =！"
);

?>
