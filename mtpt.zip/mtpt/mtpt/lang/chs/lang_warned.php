<?php

$lang_warned = array
(
	'head_warned' => "被警告用户：",
	'text_username' => "用户名",
	'text_registered' => "注册时间",
	'text_lastaccess' => "上次访问",
	'text_userclass' => "用户等级",
	'text_downloaded' => "已下载",
	'text_uploaded' => "已上传",
	'text_ratio' => "分享率",
	'text_end_of_warning' => "最后警告",
	'text_remove_warning' => "移除警告",
	'text_disable_account' => "禁止账号",
	'submit_do' => "保存更改"
);

?>
