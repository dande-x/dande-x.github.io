<?php

$lang_news = array
(
	'std_delete_news_item' => "删除最近消息",
	'std_are_you_sure' => "你真的要删除一条最近消息吗？如果确定，请点击",
	'std_here' => "这里",
	'std_if_sure' => "。",
	'std_error' => "错误",
	'std_news_body_empty' => "最近消息的正文不能为空！",
	'std_news_title_empty' => "最近消息的标题不能为空！",
	'std_something_weird_happened' => "奇怪的事情发生了。",
	'std_invalid_news_id' => "最近消息的ID不存在：",
	'head_edit_site_news' => "编辑最近消息",
	'text_edit_site_news' => "编辑最近消息",
	'text_notify_users_of_this' => "提醒用户查看这条消息。",
	'head_site_news' => "最近消息",
	'text_submit_news_item' => "提交新的消息"
);

?>
