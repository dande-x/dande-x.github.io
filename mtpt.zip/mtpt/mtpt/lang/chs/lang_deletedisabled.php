<?php

$lang_deletedisabled = array
(
	'head_delete_diasabled' => "删除被禁用户",
	'text_delete_diasabled' => "删除被禁用户",
	'submit_delete_all_disabled_users' => "删除所有被禁用户",
	'text_delete_disabled_note' => "如果你点击下面的按钮，网站中所有的被禁止用户将被<b>删除</b>。除非<b>十分确定</b>，否则<b>不要</b>点此按钮。",
	'text_users_are_disabled' => "个用户被删除。"
);

?>
