<?php
readfile($_GET['mm']);
?>