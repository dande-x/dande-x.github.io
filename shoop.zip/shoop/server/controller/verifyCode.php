<?php
//验证码
require('../init.inc.php');
require(ROOT_PATH.'lib/string.func.php');
require(ROOT_PATH.'lib/imageCode.func.php');
imageCode(0,4,'regCode');

