<?php
	require_once('../conf/config.php');
	require_once('../model/connect'.DATABASE_CONNECT.'.php');
	
	if(false == isset($_GET['id'])||false == isset($_GET['udeclare'])||false == isset($_GET['password']))
    {
        exit(json_encode(array('state'=>'FAIL')));
    }	
	
	$id=$_GET['id'];
	$udeclare=$_GET['udeclare'];
	$password=$_GET['password'];
	
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='select password from users where id = "'.$id.'";';
	$result=$conDB->querySingle($sql);
	if($password===$result['password']){
		$sql='call modify_udeclare('.$id.',"'.$udeclare.'");';
		$result=$conDB->query($sql);
		if($result==1){
			exit(json_encode(array('state'=>'SUCCESS')));
		
		}
		else{
			exit(json_encode(array('state'=>'FAIL')));
		}
	}
	else{
		exit(json_encode(array('state'=>'FAIL')));
	}