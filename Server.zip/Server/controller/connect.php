<?php
            require_once(conf/config.php);
			$dbLink=new mysqli(localhost,root,root,$serverdb);
            if(mysqli_connect_errno()){
	           exit(CONNECT_DATABASE_ERROR_CODE);
              }
            else{
	           $this->dbLink->query("set names utf8");
			   print_r(')))))))))))))');
            }
			print_r('haha');