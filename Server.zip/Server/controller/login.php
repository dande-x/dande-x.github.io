<?php
	require_once('../conf/config.php');
	require_once('../model/connect'.DATABASE_CONNECT.'.php');
	if(false == isset($_GET['email'])||false == isset($_GET['password']))
    {
       exit(json_encode(array('state'=>'FAIL')));
    }		
	$email=$_GET['email'];
	$password=$_GET['password'];
	
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='select password from users where email = "'.$email.'";';
	$result=$conDB->querySingle($sql);
	if($password===$result['password']){
		$sql='select * from users where email ="'.$email.'";';
		$result=$conDB->querySingle($sql);
		$user['state']='SUCCESS';
		$user['id']=$result['id'];
		$user['name']=$result['name'];
		$user['type']=$result['type'];
		$user['udeclare']=$result['udeclare'];
		
		exit(json_encode($user));		
		
	}
	else{
		exit(json_encode(array('state'=>'FAIL')));
	}