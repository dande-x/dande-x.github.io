<?php
	require_once('../conf/config.php');
	require_once('../model/connect'.DATABASE_CONNECT.'.php');
	if(false == isset($_GET['email'])||false == isset($_GET['code'])||false == isset($_GET['type']))
    {
       exit(json_encode(array('state'=>'FAIL')));
    }	
	
	$email=$_GET['email'];
	$code=$_GET['code'];
	$type=$_GET['type'];
	
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='select code from emails where email= "'.$email.'" and type ='.$type.';';
	$result=$conDB->querySingle($sql);
	if($result['code']==$code){
		exit(json_encode(array('state'=>'SUCCESS')));
	}else{
		exit(json_encode(array('state'=>'FAIL')));
	}
	