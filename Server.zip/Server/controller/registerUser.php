<?php
	require_once('../conf/config.php');
	require_once('../model/connect'.DATABASE_CONNECT.'.php');
	if(false == isset($_GET['email'])||false == isset($_GET['name'])||false == isset($_GET['password'])||
	false == isset($_GET['type'])||false == isset($_GET['udeclare'])
	)
    {
       exit(json_encode(array('state'=>'FAIL')));
    }	
	$email=$_GET['email'];
	$name=$_GET['name'];
	$password=$_GET['password'];
	$type=$_GET['type'];
	$udeclare=$_GET['udeclare'];
	
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='call register_user("'.$email.'","'.$name.'","'.$password.'",'.$type.',"'.$udeclare.'");';
	$result=$conDB->query($sql);

	if($result==1){
		exit(json_encode(array('state'=>'SUCCESS')));		
	}else{
		exit(json_encode(array('state'=>'FAIL')));
	}
	
	