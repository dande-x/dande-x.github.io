<?php
	require_once('../conf/config.php');
	require_once('../model/connect'.DATABASE_CONNECT.'.php');
	if(false == isset($_GET['uid'])||false == isset($_GET['tid'])||false == isset($_GET['uname'])||false == isset($_GET['content']))
    {
       exit(json_encode(array('state'=>'FAIL')));
    }	
	$uid=$_GET['uid'];
	$tid=$_GET['tid'];
	$uname=$_GET['uname'];
	$content=$_GET['content'];
	
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='call new_message('.$uid.','.$tid.',"'.$uname.'","'.$content.'");';
	$result=$conDB->query($sql);
	if($result!=0){
		exit(json_encode(array('state'=>'SUCCESS')));
	}else{
		exit(json_encode(array('state'=>'FAIL')));
	}
	/*foreach($result as $k => $id){
		print_r($id);
		exit();		
	}
		exit('FAIL');
	*/
	
	