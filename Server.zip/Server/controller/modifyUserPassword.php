<?php
	require_once('../conf/config.php');
	require_once('../model/connect'.DATABASE_CONNECT.'.php');
	if(false == isset($_GET['email'])||false == isset($_GET['newPassword']))
    {
       exit(json_encode(array('state'=>'FAIL')));
    }		
	$email=$_GET['email'];
	$newPassword=$_GET['newPassword'];
	
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='call modify_password("'.$email.'","'.$newPassword.'");';
	$result=$conDB->query($sql);
	if($result==1){
		exit(json_encode(array('state'=>'SUCCESS')));
	}
	else{
		exit(json_encode(array('state'=>'FAIL')));
	}
	