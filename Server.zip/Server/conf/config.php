<?php
   define ('DEFAULT_CHARSET','utf-8');
   
   define ('DATABASE_CONNECT','Mysqli');   //��ѡ    PDO
   define ('DATABASE_HOST','localhost');
   define ('DATABASE_USER','root');
   define ('DATABASE_PASSWORD','');  
   define ('DATABASE_DBNAME','serverdb');

   
   define ('CONNECT_DATABASE_ERROR_CODE','2');              //���ݿ����Ӵ���