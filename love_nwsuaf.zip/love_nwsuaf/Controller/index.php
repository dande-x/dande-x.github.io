<?php
echo "love_nwsuaf";