<?php
	require_once('../conf/config.php');
	require_once('../Model/connect'.DATABASE_CONNECT.'.php');
			
	$email=$_POST['email'];
	$password=$_POST['password'];
	$conDB = new ConnectDatabase(DATABASE_DBNAME);
	$sql='select password from user where email = "'.$email.'";';
	$result=$conDB->querySingle($sql);
	if($password===$result['password']){
		$sql='select * from users where email ="'.$email.'";';
		$result=$conDB->querySingle($sql);
		$user=array();
		$user['id']=$result['id'];
		$user['name']=$result['name'];
		$user['type']=$result['type'];
		$user['avatar']=$result['avatar'];
		
		print_r(json_encode($user));		
		
	}
	else{
		exit('FAIL');
	}
	
	

	
	
	
	
	
	
	
	
	
